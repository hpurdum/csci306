

public interface Switchable
{
	public void turnOn();
    public void turnOff();
}