

public class EspressoBean extends CoffeeBean
{
	public EspressoBean()
	{
		super();
		quality = "Excellent";
	}
}