

public class CoffeeBean
{
	String quality;
	String origin;
	public CoffeeBean()
	{
		super();
		quality = "Average";
	}
}