# Clue
Section: A
<br>
Names: Henry Purdum and Reed Baker
<br>
Note: If you click a border, the game will not treat this as click on a board cell, so you won't get an error message that it isn't a target