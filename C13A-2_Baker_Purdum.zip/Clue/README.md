# Clue
Section: A
<br>
Names: Henry Purdum and Reed Baker
