package clueGame;

public class Room {
	private String name;
	private BoardCell centerCell;
	private BoardCell labelCell;
	public Room() {
		super();
	}
	public String getName() {
		return null;
	}
	public BoardCell getLabelCell() {
		return new BoardCell();
	}
	public BoardCell getCenterCell() {
		return new BoardCell();
	}
}
