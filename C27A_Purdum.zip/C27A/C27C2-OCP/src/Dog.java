

public class Dog extends Pet {
	public Dog(String name) {
		super(name, "Woof", "a bone", "Thow a frisbee to " + name);
	}
}