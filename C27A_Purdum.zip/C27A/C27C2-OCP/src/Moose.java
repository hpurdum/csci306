

public class Moose extends Pet {
	public Moose(String name) {
		super(name, "Bellow", "some grass", "Watch " + name + " graze");
	}
}