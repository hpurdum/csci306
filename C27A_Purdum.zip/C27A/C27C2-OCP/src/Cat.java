

public class Cat extends Pet {
	public Cat(String name) {
		super(name, "Meow", "some catnip", "Watch " + name + " sleep");
	}
}