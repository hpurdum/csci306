

public class Mouse extends Pet {
	public Mouse(String name) {
		super(name, "Squeak", "cheese", "Watch " + name + " dodge mouse traps");
	}
}